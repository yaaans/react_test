var defaults = require('./defaults');
var Sbip = require('./core/Sbip');

function createInstance(config) {
    var instance = new Sbip(config);

    return instance;
}

var sbip = createInstance(defaults.common);

var sbipAjax = require('./core/sbipAjax.1');
sbip.ajax = new sbipAjax(defaults.ajax);

var sbipConst = require('./core/sbipConst');
sbip.const = sbipConst;

module.exports = sbip;

