module.exports = function(grunt) {
  require('load-grunt-tasks')(grunt);

  grunt.initConfig({

    clean: {
      dist: 'dist/**'
    },

    webpack: require('./webpack.config.js')
  });
  
  grunt.registerTask('build', 'Run webpack and bundle the source', ['clean', 'webpack']);
};
