
module.exports = {
    common : {

    },
    ajax : {
        
    }
};
